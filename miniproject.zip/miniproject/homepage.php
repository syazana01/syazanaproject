<!DOCTYPE html>
<html>
<head>
<title>Home Page</title>
<meta name="viewport" content="width=device-width,initial-scale=1">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.js"></script>
</head>
<style>
body{
	background:#81D8D0;
}
.navbar-inverse{
	background:white;
	padding:8px;
	font-size:20px;
	
}
.navbar-nav{
	padding: 0 0 0 20px;
	margin-left:100px;
	
}
.navbar-right{
	margin-right:220px;
	
}
</style>
<body>
<nav class="navbar navbar-inverse">
	<div class ="container-fluid">
		<div class ="navbar-header">
		<a class ="navbar-brand" href="homepage.php"><img src="Capture.png" ></a>
		</div>
		<ul class ="nav navbar-nav">
			<li><a href="homepage.php" style ="font-family:algerian,cursive;line-height: 70px;">HOME</a></li>
			<li><a href="resident.php" style ="font-family:algerian,cursive; line-height: 70px;">RESIDENT</a></li>
			<li><a href="location.php" style ="font-family:algerian,cursive; line-height: 70px;">LOCATION</a></li>
		</ul>
		<Ol class="nav navbar-nav navbar-right">
		<li><a href="login.php" style ="font-family:algerian,cursive;line-height: 70px;"><span class ="glyphicon glyphicon-login"></span>LOGIN</a></li>
		</ul>
	</div>
</nav>
<b style="font-family:algerian,cursive;"><br><center><h1> WELCOME</h1></caption></b><br><br>
<center><table border="0" width="80%">



<td >


	<td style="font-family:courier;"><h3  style="text-align:center;">STUDENT OFF-CAMPUS</h3>
	<center><p>The Off-Campus Student Management Unit is a unit established under the Student Affairs Division<br> to manage matters pertaining to the off campus students welfare and development and their well-being.
	</p>This unit is responsible for:<br> </center>
  <br><li>Establish and continuously update the Off-Campus Students database</li>
  <li>Make a continuing mapping study regarding the distribution of Off-Campus Student accommodation</li>
  <li>To assist in providing house/room-to-rent directory for Off-Campus Students</li>
  <li>Organize a dialogue session between Off-Campus Students with the local community and local authorities such as police and fire brigade</li>
  <li>Establish Off-Campus Student Action Committee as a liaison between the off-campus students with Student Affairs and University management</li>
  <li>To provide friendly visits and regular monitoring of welfare and students’ problems</li>
  <li>To encourage and assist the Off-Campus Students to participate in community programs in their neighbourhoods</li>
  <li>To help disseminate information on Off-Campus students who have difficulties (financial problems, logistics, furniture and advice) to those responsible</li>
  <li>Conduct personality development programs to Off-Campus students for their well-being, including safety, financial management, training and others</li>
  <li>To review, certify and extend Off-Campus student needs to the management of the University of Malaysia Pahang</li>
  <li>Enhance the Off-Campus student involvement in student body’s activities and the activities organized by the University of Malaysia Pahang</li>
  <center><img src="pic1.png" alt="ACER" width="100%" height="100%"></li>
  <br><br>
</ul>  
 </td>
</body>
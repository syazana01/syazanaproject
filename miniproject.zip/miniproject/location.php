<!DOCTYPE html>
<html>
<head>
<title>Home Page</title>
<meta name="viewport" content="width=device-width,initial-scale=1">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.js"></script>
</head>
<style>
body{
	background:#81D8D0;
}
.navbar-inverse{
	background:white;
	padding:8px;
	font-size:20px;
	
}
.navbar-nav{
	padding: 0 0 0 20px;
	margin-left:100px;
	
}
.navbar-right{
	margin-right:220px;
	
}
</style>
<body>
<nav class="navbar navbar-inverse">
	<div class ="container-fluid">
		<div class ="navbar-header">
		<a class ="navbar-brand" href="homepage.php"><img src="Capture.png" ></a>
		</div>
		<ul class ="nav navbar-nav">
			<li><a href="homepage.php" style ="font-family:algerian,cursive;line-height: 70px;">HOME</a></li>
			<li><a href="resident.php" style ="font-family:algerian,cursive; line-height: 70px;">RESIDENT</a></li>
			<li><a href="location.php" style ="font-family:algerian,cursive; line-height: 70px;">LOCATION</a></li>
		</ul>
		<Ol class="nav navbar-nav navbar-right">
		<li><a href="login.php" style ="font-family:algerian,cursive;line-height: 70px;"><span class ="glyphicon glyphicon-login"></span>LOGIN</a></li>
		</ul>
	</div>
</nav>

<center><table border="0" width="70%"><br><br>

<caption style="font-family:courier;"><h3  style="text-align:center;">LOCATION</h3></b><br>
<center><p>We're located near to the campus.<br>It is easy & fast to reach there</p><br><br>
<tr>
<td rowspan="1">
<center><img src="h4.png" alt="pic4" width="392px" height="346px">
	<td style="font-family:courier;"><h4>GAMBANG DAMAI RESIDENT</h4><br>Copy & Paste to view location : <br><br>https://goo.gl/maps/Av8xAeGpfGw<b>
  </tr>
  <tr>
<td rowspan="1">
<center><img src="h3.png" alt="pic4" width="392px" height="346px">
	<td style="font-family:courier;"><h4>TAMAN MAKMUR KG FAJAR RESIDENT</h4><br>Copy & Paste to view location : <br><br>https://goo.gl/maps/5NynEc8XKPs<b>
  </tr>
 <br><br>
 
 <center><table border="0" width="70%"><br><br>

<caption style="font-family:courier;"><h3  style="text-align:center;">HOW TO GET HERE</h3></b><br><br><br>
<td rowspan="1" style="font-family:courier;"><h4>by TAXI</h4><br>Cost charge : <br>Gambang Damai Resident to campus is RM8<br>Taman Makmur Kg Fajar Resident to campus is RM6<b>

	<td><center><img src="h5.png" alt="pic4" width="392px" height="346px">
  </tr>
  <tr>
<td rowspan="1">
<center><img src="h6.png" alt="pic4" width="392px" height="346px">
	<td style="font-family:courier;"><h4>by BUS</h4><br>Cost charge : <br>Gambang Damai Resident to campus is RM4<br>Taman Makmur Kg Fajar Resident to campus is RM4<b>
   <br><br>
  </tr>

</body>